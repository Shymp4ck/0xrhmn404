package main

const (
	homeFlag        = "home"
	forceFlag       = "force"
	rpcListenerFlag = "rpc-listener"
)
