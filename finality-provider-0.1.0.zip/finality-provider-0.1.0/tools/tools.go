//go:build tools
// +build tools

package finalityprovider

import (
	_ "github.com/babylonchain/babylon/cmd/babylond"
)
